# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['trivial']

package_data = \
{'': ['*']}

install_requires = \
['Flask>=1.1.1,<2.0.0', 'alembic==1.0.10']

setup_kwargs = {
    'name': 'trivial',
    'version': '0.1.0',
    'description': 'poetry2nix test',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
